--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.4
-- Dumped by pg_dump version 16.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "shopPetDB";
--
-- Name: shopPetDB; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "shopPetDB" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Vietnamese_Vietnam.1258';


ALTER DATABASE "shopPetDB" OWNER TO postgres;

\connect "shopPetDB"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: admin_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.admin_log (
    log_id character varying NOT NULL,
    admin_id character varying NOT NULL,
    action character varying NOT NULL,
    "timestamp" character varying NOT NULL
);


ALTER TABLE public.admin_log OWNER TO postgres;

--
-- Name: cart; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cart (
    card_id character varying NOT NULL,
    user_id character varying NOT NULL,
    create_at date NOT NULL
);


ALTER TABLE public.cart OWNER TO postgres;

--
-- Name: cart_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cart_items (
    cart_item_id character varying NOT NULL,
    cart_id character varying,
    product_id character varying,
    amount integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.cart_items OWNER TO postgres;

--
-- Name: categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.categories (
    category_id character varying NOT NULL,
    name character varying,
    parent_id character varying[]
);


ALTER TABLE public.categories OWNER TO postgres;

--
-- Name: order_Items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."order_Items" (
    order_item_id character varying NOT NULL,
    order_id character varying NOT NULL,
    product_id character varying NOT NULL,
    quantity integer DEFAULT 1 NOT NULL,
    price character varying NOT NULL
);


ALTER TABLE public."order_Items" OWNER TO postgres;

--
-- Name: orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.orders (
    order_id character varying NOT NULL,
    user_id character varying NOT NULL,
    total_price character varying DEFAULT 0 NOT NULL,
    status character varying NOT NULL,
    created_at date,
    voucher_id character varying
);


ALTER TABLE public.orders OWNER TO postgres;

--
-- Name: payments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payments (
    payment_id character varying NOT NULL,
    order_id character varying NOT NULL,
    payment_method character varying NOT NULL,
    status boolean NOT NULL,
    created_at date NOT NULL
);


ALTER TABLE public.payments OWNER TO postgres;

--
-- Name: products; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.products (
    product_id character varying NOT NULL,
    name character varying(50) NOT NULL,
    description character varying NOT NULL,
    price character varying NOT NULL,
    stock_quantity character varying NOT NULL,
    category_id character varying NOT NULL,
    created_at date NOT NULL,
    image character varying NOT NULL
);


ALTER TABLE public.products OWNER TO postgres;

--
-- Name: rate_product; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rate_product (
    productid character varying,
    userid character varying,
    rate integer,
    comment character varying
);


ALTER TABLE public.rate_product OWNER TO postgres;

--
-- Name: user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."user" (
    user_id character varying NOT NULL,
    username character varying(50) NOT NULL,
    password character varying NOT NULL,
    mail character varying(100),
    name character varying(100),
    phone integer,
    address character varying,
    created_at date,
    role character varying DEFAULT USER,
    image character varying
);


ALTER TABLE public."user" OWNER TO postgres;

--
-- Name: visits; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.visits (
    user_id character varying,
    visit_date date
);


ALTER TABLE public.visits OWNER TO postgres;

--
-- Name: voucher_use; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.voucher_use (
    user_id character varying NOT NULL,
    voucher_id character varying NOT NULL
);


ALTER TABLE public.voucher_use OWNER TO postgres;

--
-- Name: vouchers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.vouchers (
    voucher_id character varying NOT NULL,
    code character varying NOT NULL,
    discount character varying NOT NULL,
    expiry_date date NOT NULL,
    min_order_value character varying
);


ALTER TABLE public.vouchers OWNER TO postgres;

--
-- Data for Name: admin_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.admin_log (log_id, admin_id, action, "timestamp") FROM stdin;
\.
COPY public.admin_log (log_id, admin_id, action, "timestamp") FROM '$$PATH$$/4928.dat';

--
-- Data for Name: cart; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cart (card_id, user_id, create_at) FROM stdin;
\.
COPY public.cart (card_id, user_id, create_at) FROM '$$PATH$$/4929.dat';

--
-- Data for Name: cart_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cart_items (cart_item_id, cart_id, product_id, amount) FROM stdin;
\.
COPY public.cart_items (cart_item_id, cart_id, product_id, amount) FROM '$$PATH$$/4932.dat';

--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.categories (category_id, name, parent_id) FROM stdin;
\.
COPY public.categories (category_id, name, parent_id) FROM '$$PATH$$/4930.dat';

--
-- Data for Name: order_Items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."order_Items" (order_item_id, order_id, product_id, quantity, price) FROM stdin;
\.
COPY public."order_Items" (order_item_id, order_id, product_id, quantity, price) FROM '$$PATH$$/4935.dat';

--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.orders (order_id, user_id, total_price, status, created_at, voucher_id) FROM stdin;
\.
COPY public.orders (order_id, user_id, total_price, status, created_at, voucher_id) FROM '$$PATH$$/4927.dat';

--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payments (payment_id, order_id, payment_method, status, created_at) FROM stdin;
\.
COPY public.payments (payment_id, order_id, payment_method, status, created_at) FROM '$$PATH$$/4936.dat';

--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.products (product_id, name, description, price, stock_quantity, category_id, created_at, image) FROM stdin;
\.
COPY public.products (product_id, name, description, price, stock_quantity, category_id, created_at, image) FROM '$$PATH$$/4931.dat';

--
-- Data for Name: rate_product; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rate_product (productid, userid, rate, comment) FROM stdin;
\.
COPY public.rate_product (productid, userid, rate, comment) FROM '$$PATH$$/4937.dat';

--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."user" (user_id, username, password, mail, name, phone, address, created_at, role, image) FROM stdin;
\.
COPY public."user" (user_id, username, password, mail, name, phone, address, created_at, role, image) FROM '$$PATH$$/4926.dat';

--
-- Data for Name: visits; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.visits (user_id, visit_date) FROM stdin;
\.
COPY public.visits (user_id, visit_date) FROM '$$PATH$$/4938.dat';

--
-- Data for Name: voucher_use; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.voucher_use (user_id, voucher_id) FROM stdin;
\.
COPY public.voucher_use (user_id, voucher_id) FROM '$$PATH$$/4934.dat';

--
-- Data for Name: vouchers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.vouchers (voucher_id, code, discount, expiry_date, min_order_value) FROM stdin;
\.
COPY public.vouchers (voucher_id, code, discount, expiry_date, min_order_value) FROM '$$PATH$$/4933.dat';

--
-- Name: admin_log admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admin_log
    ADD CONSTRAINT admin_log_pkey PRIMARY KEY (log_id, admin_id);


--
-- Name: cart_items cart_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cart_items
    ADD CONSTRAINT cart_items_pkey PRIMARY KEY (cart_item_id);


--
-- Name: cart cart_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cart
    ADD CONSTRAINT cart_pkey PRIMARY KEY (card_id);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (category_id);


--
-- Name: order_Items order_Items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."order_Items"
    ADD CONSTRAINT "order_Items_pkey" PRIMARY KEY (order_item_id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (order_id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (payment_id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (product_id);


--
-- Name: user user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_pkey PRIMARY KEY (user_id);


--
-- Name: vouchers vouchers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vouchers
    ADD CONSTRAINT vouchers_pkey PRIMARY KEY (voucher_id);


--
-- Name: admin_log admin_log_admin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admin_log
    ADD CONSTRAINT admin_log_admin_id_fkey FOREIGN KEY (admin_id) REFERENCES public."user"(user_id);


--
-- Name: cart_items cart_items_card_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cart_items
    ADD CONSTRAINT cart_items_card_id_fkey FOREIGN KEY (cart_id) REFERENCES public.cart(card_id);


--
-- Name: cart_items cart_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cart_items
    ADD CONSTRAINT cart_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(product_id);


--
-- Name: cart cart_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cart
    ADD CONSTRAINT cart_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(user_id);


--
-- Name: order_Items order_Items_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."order_Items"
    ADD CONSTRAINT "order_Items_order_id_fkey" FOREIGN KEY (order_id) REFERENCES public.orders(order_id);


--
-- Name: order_Items order_Items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."order_Items"
    ADD CONSTRAINT "order_Items_product_id_fkey" FOREIGN KEY (product_id) REFERENCES public.products(product_id);


--
-- Name: orders orders_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(user_id);


--
-- Name: payments payments_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(order_id);


--
-- Name: products products_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(category_id);


--
-- Name: rate_product rate_product_productID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rate_product
    ADD CONSTRAINT "rate_product_productID_fkey" FOREIGN KEY (productid) REFERENCES public.products(product_id);


--
-- Name: rate_product rate_product_userID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rate_product
    ADD CONSTRAINT "rate_product_userID_fkey" FOREIGN KEY (userid) REFERENCES public."user"(user_id);


--
-- Name: voucher_use voucher_use_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.voucher_use
    ADD CONSTRAINT voucher_use_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(user_id);


--
-- Name: voucher_use voucher_use_voucher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.voucher_use
    ADD CONSTRAINT voucher_use_voucher_id_fkey FOREIGN KEY (voucher_id) REFERENCES public.vouchers(voucher_id);


--
-- PostgreSQL database dump complete
--

